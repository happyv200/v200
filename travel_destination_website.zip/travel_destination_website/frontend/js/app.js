
// travel_destination_website/frontend/js/app.js
document.addEventListener('DOMContentLoaded', function() {
  // 初始化本地存储数据
  if (!localStorage.getItem('travelAppData')) {
    localStorage.setItem('travelAppData', JSON.stringify({
      likes: {},
      favorites: {},
      comments: {}
    }));
  }

  const appData = JSON.parse(localStorage.getItem('travelAppData'));
  
  // 获取当前页面ID
  const urlParams = new URLSearchParams(window.location.search);
  const pageId = urlParams.get('id') || 'index';
  
  // 加载本地JSON数据
  fetch('data/destinations.json')
    .then(response => response.json())
    .then(data => {
      // 首页功能
      if (pageId === 'index') {
        // 初始化首页卡片数据
        const destinationCards = document.querySelectorAll('.destination-card');
        destinationCards.forEach(card => {
          const cardId = card.getAttribute('href').split('=')[1];
          const destination = data.find(item => item.id == cardId);
          
          if (destination) {
            // 更新卡片图片
            const img = card.querySelector('img');
            if (img) img.src = `assets/images/${destination.thumbnail}`;
            
            // 更新卡片内容
            const title = card.querySelector('h3');
            if (title) title.textContent = destination.name;
            
            const desc = card.querySelector('p');
            if (desc) desc.textContent = destination.shortDescription;
            
            // 从本地存储获取点赞数
            const likes = appData.likes[cardId] || destination.likes;
            const likeCountElement = card.querySelector('.mr-2');
            if (likeCountElement) {
              likeCountElement.textContent = `❤️ ${likes >= 1000 ? (likes/1000).toFixed(1)+'k' : likes}`;
            }
          }
        });
      } 
      // 详情页功能
      else {
        const destination = data.find(item => item.id == pageId);
        if (destination) {
          // 更新详情页内容
          document.getElementById('destination-title').textContent = destination.name;
          document.getElementById('destination-content').innerHTML = destination.content;
          document.getElementById('destination-tips').innerHTML = destination.tips;
          
          // 更新轮播图
          const carouselInner = document.querySelector('.carousel-inner');
          carouselInner.innerHTML = '';
          destination.images.forEach((image, index) => {
            const item = document.createElement('div');
            item.className = 'carousel-item';
            item.innerHTML = `<img src="assets/images/${image}" alt="${destination.name}图片${index + 1}">`;
            carouselInner.appendChild(item);
          });
          
          // 初始化轮播图功能
          initCarousel();
        }
      }
    })
    .catch(error => {
      console.error('加载本地数据失败:', error);
    });

  // 初始化轮播图功能
  function initCarousel() {
    const carouselInner = document.querySelector('.carousel-inner');
    const carouselItems = document.querySelectorAll('.carousel-item');
    const prevBtn = document.querySelector('.carousel-control.prev');
    const nextBtn = document.querySelector('.carousel-control.next');
    const indicators = document.querySelectorAll('.carousel-indicator');
    
    if (!carouselItems.length) return;
    
    let currentIndex = 0;
    const itemWidth = carouselItems[0].clientWidth;
    const totalItems = carouselItems.length;
    
    function updateCarousel() {
      carouselInner.style.transform = `translateX(-${currentIndex * itemWidth}px)`;
      indicators.forEach((indicator, index) => {
        indicator.classList.toggle('active', index === currentIndex);
      });
    }
    
    prevBtn.addEventListener('click', () => {
      currentIndex = (currentIndex - 1 + totalItems) % totalItems;
      updateCarousel();
    });
    
    nextBtn.addEventListener('click', () => {
      currentIndex = (currentIndex + 1) % totalItems;
      updateCarousel();
    });
    
    indicators.forEach((indicator, index) => {
      indicator.addEventListener('click', () => {
        currentIndex = index;
        updateCarousel();
      });
    });
    
    // 自动轮播
    setInterval(() => {
      currentIndex = (currentIndex + 1) % totalItems;
      updateCarousel();
    }, 5000);
  }

  // 点赞和收藏功能
  const likeBtn = document.getElementById('like-btn');
  const favoriteBtn = document.getElementById('favorite-btn');
  const likeCount = document.getElementById('like-count');
  
  if (likeBtn && favoriteBtn && likeCount) {
    const currentLikes = appData.likes[pageId] || parseInt(likeCount.textContent.replace('k', '')) * 1000 || 1200;
    const isLiked = localStorage.getItem(`liked_${pageId}`) === 'true';
    const isFavorited = localStorage.getItem(`favorited_${pageId}`) === 'true';
    
    likeCount.textContent = currentLikes >= 1000 ? (currentLikes/1000).toFixed(1)+'k' : currentLikes;
    if (isLiked) likeBtn.classList.add('active');
    if (isFavorited) {
      favoriteBtn.classList.add('active');
      favoriteBtn.innerHTML = '<span>⭐</span><span>已收藏</span>';
    }
    
    // 点赞功能
    likeBtn.addEventListener('click', function() {
      const newIsLiked = !isLiked;
      const newLikes = newIsLiked ? currentLikes + 1 : currentLikes - 1;
      
      appData.likes[pageId] = newLikes;
      localStorage.setItem('travelAppData', JSON.stringify(appData));
      localStorage.setItem(`liked_${pageId}`, newIsLiked.toString());
      
      likeCount.textContent = newLikes >= 1000 ? (newLikes/1000).toFixed(1)+'k' : newLikes;
      likeBtn.classList.toggle('active', newIsLiked);
    });
    
    // 收藏功能
    favoriteBtn.addEventListener('click', function() {
      const newIsFavorited = !isFavorited;
      
      appData.favorites[pageId] = newIsFavorited;
      localStorage.setItem('travelAppData', JSON.stringify(appData));
      localStorage.setItem(`favorited_${pageId}`, newIsFavorited.toString());
      
      favoriteBtn.classList.toggle('active', newIsFavorited);
      favoriteBtn.innerHTML = newIsFavorited ? 
        '<span>⭐</span><span>已收藏</span>' : 
        '<span>⭐</span><span>收藏</span>';
    });
  }
  
  // 评论功能
  const commentInput = document.getElementById('comment-input');
  const submitComment = document.getElementById('submit-comment');
  const commentsContainer = document.getElementById('comments-container');
  
  if (commentInput && submitComment && commentsContainer) {
    // 加载已有评论
    if (appData.comments[pageId]) {
      appData.comments[pageId].forEach(comment => {
        addCommentToDOM(comment);
      });
    }
    
    // 提交新评论
    submitComment.addEventListener('click', function() {
      const commentText = commentInput.value.trim();
      if (commentText) {
        const newComment = {
          id: Date.now(),
          author: '匿名用户',
          text: commentText,
          timestamp: new Date().toISOString()
        };
        
        // 保存到本地存储
        if (!appData.comments[pageId]) {
          appData.comments[pageId] = [];
        }
        appData.comments[pageId].unshift(newComment);
        localStorage.setItem('travelAppData', JSON.stringify(appData));
        
        // 添加到DOM
        addCommentToDOM(newComment);
        commentInput.value = '';
      }
    });
    
    function addCommentToDOM(comment) {
      const timeAgo = getTimeAgo(comment.timestamp);
      
      const commentElement = document.createElement('div');
      commentElement.className = 'comment-item border-b border-gray-100 pb-4';
      commentElement.innerHTML = `
        <div class="flex items-center mb-2">
          <div class="w-8 h-8 rounded-full bg-gray-300 mr-2"></div>
          <span class="font-medium">${comment.author}</span>
          <span class="text-gray-500 text-sm ml-auto">${timeAgo}</span>
        </div>
        <p class="text-gray-700">${comment.text}</p>
      `;
      
      commentsContainer.prepend(commentElement);
    }
    
    function getTimeAgo(timestamp) {
      const now = new Date();
      const commentDate = new Date(timestamp);
      const diffInSeconds = Math.floor((now - commentDate) / 1000);
      
      if (diffInSeconds < 60) return '刚刚';
      if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds/60)}分钟前`;
      if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds/3600)}小时前`;
      return `${Math.floor(diffInSeconds/86400)}天前`;
    }
  }
  
  // 分享功能
  const shareBtn = document.querySelector('header button');
  if (shareBtn && shareBtn.textContent.includes('分享')) {
    shareBtn.addEventListener('click', function() {
      if (navigator.share) {
        navigator.share({
          title: document.title,
          text: '看看这个超棒的旅行目的地！',
          url: window.location.href
        }).catch(err => {
          console.log('分享失败:', err);
          alert('分享功能正在开发中');
        });
      } else {
        alert('分享功能正在开发中');
      }
    });
  }
});
